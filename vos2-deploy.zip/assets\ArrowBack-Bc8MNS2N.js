import{aA as r,aq as a,an as t}from"./index-D-rzqL67.js";var e={},o=t;Object.defineProperty(e,"__esModule",{value:!0});var u=e.default=void 0,i=o(r()),l=a;u=e.default=(0,i.default)((0,l.jsx)("path",{d:"M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20z"}),"ArrowBack");export{u as d};
//# sourceMappingURL=ArrowBack-Bc8MNS2N.js.map
