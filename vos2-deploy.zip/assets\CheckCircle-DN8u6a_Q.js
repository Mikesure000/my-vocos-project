import{aA as r,aq as a,an as t}from"./index-D-rzqL67.js";var e={},u=t;Object.defineProperty(e,"__esModule",{value:!0});var i=e.default=void 0,o=u(r()),l=a;i=e.default=(0,o.default)((0,l.jsx)("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m-2 15-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8z"}),"CheckCircle");export{i as d};
//# sourceMappingURL=CheckCircle-DN8u6a_Q.js.map
